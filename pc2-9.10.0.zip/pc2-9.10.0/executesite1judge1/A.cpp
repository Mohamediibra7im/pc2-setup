#include <bits/stdc++.h>
using namespace std;

int main()
{
    string str;
    cin >> str;
    cout << "World" << endl;
}